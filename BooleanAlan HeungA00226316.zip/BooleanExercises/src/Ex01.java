// Alan Heung A00226316
public class Ex01 {
	public static void main(String[] args) {
		int a=4, b=7;
		boolean c;
		if(a < 0 && b >0){
			c = true;
		}else{
			c = false;

		}
		System.out.println(c);		
	}

}
