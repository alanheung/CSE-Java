// Alan Heung A00226316
import java.util.Scanner;
public class Ex04{
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		//Ask user what their scores are and get input
		System.out.print("Please enter your quiz score: ");
		int quizScore = sc.nextInt();	
		System.out.print("Please enter your midterm score: ");
		int midtermScore = sc.nextInt();
		System.out.print("Please enter your final score: ");
		int finalScore = sc.nextInt();	
		//Display the scores
		System.out.println("Quiz score: "+quizScore);
		System.out.println("Midterm score:"+ midtermScore);
		System.out.println("Final score: "+finalScore);
		//Check for total score
		int totalScore= ((quizScore+midtermScore+finalScore)/3);
		System.out.println("Total score: "+ totalScore);
		if(totalScore >= 90 && totalScore <=100 ){
			System.out.println("Your grade is A1 ");
		}else if(totalScore >= 80 && totalScore <=89 ){
				System.out.println( "Your grade is A2");
		}else if(totalScore >= 70 && totalScore <=79){
			System.out.println( "Your grade is B");
		}else if(totalScore >= 50 && totalScore <=69){
			System.out.println( "Your grade is C");
		}else if(totalScore >= 40 && totalScore <=49){
			System.out.println( "Your grade is D");
		}else{
			System.out.println( "Your grade is F");
		}
	}
}
