package com.mase.oop1.code2;

public interface Memoryl {
	String getMemoryCapacity();
}
