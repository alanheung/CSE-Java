package com.mase.oop1;

public interface ElectronicDevice{
	public void turnOn();
	public void turnOff();
	public String getTheMake();
	public String getTheModel();
}
