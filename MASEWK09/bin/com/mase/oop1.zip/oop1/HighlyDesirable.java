package com.mase.oop1;

public interface HighlyDesirable {
	void sysout();
}
