import java.util.Date;

public class Biscuit {
	private int theNumberOfBiscuits;
	private int theWeight;
	private String theBrand;
	private String theMaker;
	private Date BBD;
	
	Biscuit(){
		theNumberOfBiscuits = 0;
		theWeight = 0;
		theBrand = "";
		theMaker ="";
	}
	
	
	Biscuit(String aBrand, String aMaker, int aWeight, int aNumberOfBiscuits, Date aBBD){
		theMaker = aMaker;
		theBrand = aBrand;
		theWeight = aWeight;
		theNumberOfBiscuits = aNumberOfBiscuits;
		BBD = aBBD;
	
	}
	
	public String getBrand(){
		return theBrand;
	}
	
	public void setBrand(String aBrand){
		theBrand = aBrand;
	}
	
	public int getNumberOfBiscuits(){
		return theNumberOfBiscuits;
	}
	
	public void setNumberOfBiscuits(int aNumberOfBiscuits){
		theNumberOfBiscuits = aNumberOfBiscuits;
	}
	
	public int getWeight(){
		return theWeight;
	}
	
	public void setWeight(int aWeight){
		theWeight = aWeight;
	}
	
	public String getMaker(){
		return theMaker;
	}
	
	
	public void setMaker(String aMaker){
		theMaker = aMaker;
		
	}
	
	public void bestBeforeDate(){
		
	}
	
	
	@Override
	public String toString(){
		String ans= "Brand: "+ getBrand()+ " Maker: "+getMaker()+ " Weight: "+getWeight()+ "kg Number: "+getNumberOfBiscuits() + " Best Before Date " + BBD;
		return ans;
	}
	
	
}
